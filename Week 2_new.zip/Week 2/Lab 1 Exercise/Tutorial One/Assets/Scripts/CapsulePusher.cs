﻿using UnityEngine;
using System.Collections;

public class CapsulePusher : MonoBehaviour {

    float power = 10.0f;
    float jumpPower = 100.0f;
    bool grounded = true;

    //Input.GetKey(keyName) returns a bool when that key is hit
	void Update () {
        //Code some movement using rigidbody/AddForce for the capsule character.

        if (Input.GetKey("space") && grounded )
        {
            GetComponent<Rigidbody>().AddForce(new Vector3(0.0f, power, 0.0f), ForceMode.Impulse);
            grounded = false;
        }
        if (Input.GetKey("up"))
        {
            GetComponent<Rigidbody>().AddForce(new Vector3(0.0f,0.0f, power), ForceMode.Acceleration);
        }
        if (Input.GetKey("down"))
        {
            GetComponent<Rigidbody>().AddForce(new Vector3(0.0f, 0.0f, -power), ForceMode.Acceleration);
        }
        if (Input.GetKey("left"))
        {
            GetComponent<Rigidbody>().AddForce(new Vector3(-power, 0.0f, 0.0f), ForceMode.Acceleration);
        }
        if (Input.GetKey("right"))
        {
            GetComponent<Rigidbody>().AddForce(new Vector3(power, 0.0f, 0.0f), ForceMode.Acceleration);
        }
    }

    void OnCollisionEnter(Collision collision)
    {
        if (collision.collider.gameObject.name == "Floor")
        {
            grounded = true;
        }
    }
}
