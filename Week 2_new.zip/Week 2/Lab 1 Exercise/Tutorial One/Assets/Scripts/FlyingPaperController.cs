﻿using UnityEngine;
using System.Collections;

public class FlyingPaperController : MonoBehaviour {

    float power = 1.0f;
	void Start () {
        //You might want to use Destroy(gameObject,timer) to junk
        //objects if you're spawning a lot.
    }


    void Update () {
        //Look up Unity's Rigidbody docs, add a force to your enemies to move them around
    }
}
