﻿using UnityEngine;
using System.Collections;

public class PaperFactory : MonoBehaviour {

    
    public GameObject PaperEnemy;
    int timer = 0;
    //Random.Range(float,float) returns a random number
    float range = 40.0f;
    float ceiling = 10.0f;
	
	
	void Update () {
        //Update calls at the computer's frame rate.  You can use this fact to implement a timer
        ++timer;
        if(timer == 2)
        {
            //Make some objects dynamically from the set prefab. Use Instantiate(prefab, position, orientation)
            GameObject EnemySpawn = (GameObject) Instantiate(PaperEnemy, new Vector3(Random.Range(range,-range), Random.Range(0.0f, ceiling), Random.Range(range, -range)), Quaternion.identity);
        }
        
    }
}
