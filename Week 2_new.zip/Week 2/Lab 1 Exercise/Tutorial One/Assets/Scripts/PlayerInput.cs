﻿using UnityEngine;
using System.Collections;


public class PlayerInput : MonoBehaviour
{
    // accepts input and animates the player
    Animator player_animator;

    //TODO :- add the code necessary to animate Robot Kyle and 
    // give him movement with velocity and acceleration
    float max_velocity = 5f;
    float deaccelerator = 5f;
    float max_accelerattion = 17f;

	public float rotationDegreesPerSecond = 360;
    public float velocity = 0f;
    public float horizontal = 0;
    public float vertical = 0;
    public Vector2 input_info;
    void Start ()
    {
        //TODO :- cache the animator..?
        player_animator = GetComponent<Animator>();
    }




    void Update ()
    {
        // Obtain input information (See "Horizontal" and "Vertical" in the Input Manager)
        horizontal = Input.GetAxis ("Horizontal");
        vertical = Input.GetAxis ("Vertical");
        input_info.x = horizontal;
        input_info.y = vertical;

        //float input_mag = input_info.magnitude;
        
        // Check for inputs
		if (!Mathf.Approximately (vertical, 0.0f) || !Mathf.Approximately (horizontal, 0.0f)) {
			Vector3 direction = new Vector3 (horizontal, 0.0f, vertical);
			direction = Vector3.ClampMagnitude (direction, 1.0f);

			// look towards the input direction
			transform.rotation = Quaternion.RotateTowards (transform.rotation, Quaternion.LookRotation (direction), rotationDegreesPerSecond * Time.deltaTime);

            //TODO :- make the character move according to the input
            // You might want to only increment or decrement a velocity variable here and make the displacement
            // code lie outside this condition. But its entirely upto you, the programmer, to decide
            if (velocity < max_velocity)
            {
                velocity += max_accelerattion * Time.deltaTime;
                if (velocity > max_velocity)
                    velocity = max_velocity;
            }

		}
        //deaccelerate when no input coming
        else if (velocity > 0)
        {
            velocity -= velocity * deaccelerator * Time.deltaTime;

            //cap velocity
            if (velocity < 0)
                velocity = 0;
        }
        else
        {
            velocity = 0;
        }
        //#IMPORTANT# update the position.
        transform.position += transform.forward * velocity * Time.deltaTime;

        // Add displacement code here if you wish. Add animation code here if you wish.
        player_animator.SetFloat("Blend", velocity / max_velocity);
    }
}
