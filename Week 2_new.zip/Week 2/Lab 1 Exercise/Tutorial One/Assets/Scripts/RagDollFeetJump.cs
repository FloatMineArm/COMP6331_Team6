﻿using UnityEngine;
using System.Collections;

//This file is to make grounding checks make more sense on the ragdoll.
public class RagDollFeetJump : MonoBehaviour {

    float power = 100.0f;
    float jumpPower = 100.0f;
    bool grounded = true;

    void Update()
    {
        if (Input.GetKey("x") && grounded)
        {
            GetComponent<Rigidbody>().AddForce(new Vector3(0.0f, jumpPower, 0.0f), ForceMode.Impulse);
            grounded = false;
        }
    }

    void OnCollisionEnter(Collision collision)
    {
        if (collision.collider.gameObject.name == "Floor")
        {
            grounded = true;
        }
    }
}
