﻿using UnityEngine;
using System.Collections;

public class RagDollPusher : MonoBehaviour {

    float power = 100.0f;
    float jumpPower = 1000.0f;
    bool grounded = true;

    void Update()
    {
        //Movement using rigidbodies+forces movement
        //Using this format is preferable to modifying transform.position
        if (Input.GetKey("x") && grounded)
        {
            //Forcemode.Impulse applies the force over several frames
            //This is why we gate the call with the "grounded" variable.
            //If you were to apply it every frame, Bonzo's Compatriot would rocket into
            //the stratosphere
			// TODO :- make kyles campanion jump through the power of unity physics!
            grounded = false;
        }
        if (Input.GetKey("w"))
        {
            // Forcemode.Acceleration takes mass out of the equation.  It lets you use AddForce to
            // generically apply acceleration to the object.
			// TODO :- make kyles campanion move through the power of unity physics!
            
        }
        if (Input.GetKey("s"))
        {
           
        }
        if (Input.GetKey("a"))
        {
			
        }
        if (Input.GetKey("d"))
        {
			
        }
    }

    void OnCollisionEnter(Collision collision)
    {
        if (collision.collider.gameObject.name == "Floor")
        {
            grounded = true;
        }
    }
}
