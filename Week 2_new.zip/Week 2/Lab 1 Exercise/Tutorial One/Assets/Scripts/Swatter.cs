﻿using UnityEngine;

//If you're using the Canvas/UI, you need to include this lib
using UnityEngine.UI;
using System.Collections;

public class Swatter : MonoBehaviour {

   //These references were set in the editor via drag+drop.
    public Text POINTS; 
    public GameObject pointsplosion;
    public SwatterNetwork swatterNetwork;

    //ScriptableObject data persists between runs, as it's treated like an asset/prefab.
    //This is useful for save files, but here we prefer to reset the score to 0 on loading.
    void Start()
    {
        swatterNetwork.score = 0;
    }

    
    void OnCollisionEnter(Collision collision)
    {
        if (collision.collider.gameObject.name == "Flying Paper Enemy(Clone)")
        {
            //Increment the score in the Canvas Text here via POINTS.text
            ++swatterNetwork.score;
            POINTS.text = "POINTS:" + swatterNetwork.score;

            //This is the place to instantiate any particle systems you want to
            GameObject particles = Instantiate( pointsplosion, 
                collision.gameObject.transform.position,              //You can check what you collided with via collision
                Quaternion.identity);
            Destroy(particles, 1f);

            //and do cleanup on the object you collided with as well.
            Destroy(collision.gameObject);
  
        }
    }
}
