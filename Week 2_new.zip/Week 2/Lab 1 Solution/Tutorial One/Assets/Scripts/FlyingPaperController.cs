﻿using UnityEngine;
using System.Collections;

public class FlyingPaperController : MonoBehaviour {

    float power = 1.0f;

    //You might want to use Destroy(gameObject,timer) to junk
    //objects if you're spawning a lot.
	void Start () {
        Destroy(gameObject, 2.0f);
	}
	
    //Look up Unity's Rigidbody docs, add a force to your enemies to move them around
	void Update () {
        GetComponent<Rigidbody>().AddForce(new Vector3(Random.Range(-power, power), Random.Range(-power, power), Random.Range(-power, power)), ForceMode.Force);
    }
}
