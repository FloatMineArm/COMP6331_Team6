﻿using UnityEngine;
using System.Collections;

public class PaperFactory : MonoBehaviour {

    
    public GameObject PaperEnemy;
    int timer = 0;
    float range = 40.0f;
    float ceiling = 10.0f;
	
	//Instantiate(prefab, position, orientation)
    //cast it using (GameObject)
	void Update () {
        ++timer;
        if (timer == 1)
        {
            timer = 0;
            GameObject EnemySpawn = (GameObject)Instantiate(PaperEnemy, new Vector3(Random.Range(-range, range), Random.Range(0.0f, ceiling), Random.Range(-range, range)), Quaternion.identity);
            GameObject EnemySpawn2 = (GameObject)Instantiate(PaperEnemy, new Vector3(Random.Range(-range, range), Random.Range(0.0f, ceiling), Random.Range(-range, range)), Quaternion.identity);

        }
    }
}
