﻿using UnityEngine;
using System.Collections;

public class RagDollPusher : MonoBehaviour {

    float power = 100.0f;
    float jumpPower = 1000.0f;
    bool grounded = true;

    void Update()
    {
        //Movement using rigidbodies+forces movement
        //Using this format is preferable to modifying transform.position
        if (Input.GetKey("x") && grounded)
        {
            //Forcemode.Impulse applies the force over several frames
            //This is why we gate the call with the "grounded" variable.
            //If you were to apply it every frame, Bonzo's Compatriot would rocket into
            //the stratosphere
            GetComponent<Rigidbody>().AddForce(new Vector3(0.0f, power, 0.0f), ForceMode.Impulse);
            grounded = false;
        }
        if (Input.GetKey("w"))
        {
            // Forcemode.Acceleration takes mass out of the equation.  It lets you use AddForce to
            // generically apply acceleration to the object.
            GetComponent<Rigidbody>().AddForce(new Vector3(0.0f, 0.0f, power), ForceMode.Acceleration);
        }
        if (Input.GetKey("s"))
        {
            GetComponent<Rigidbody>().AddForce(new Vector3(0.0f, 0.0f, -power), ForceMode.Acceleration);
        }
        if (Input.GetKey("a"))
        {
            GetComponent<Rigidbody>().AddForce(new Vector3(-power, 0.0f, 0.0f), ForceMode.Acceleration);
        }
        if (Input.GetKey("d"))
        {
            GetComponent<Rigidbody>().AddForce(new Vector3(power, 0.0f, 0.0f), ForceMode.Acceleration);
        }
    }

    void OnCollisionEnter(Collision collision)
    {
        if (collision.collider.gameObject.name == "Floor")
        {
            grounded = true;
        }
    }
}
