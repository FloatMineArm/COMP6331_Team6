﻿using UnityEngine;
using System.Collections;

[CreateAssetMenu(fileName = "SwatterNetwork", menuName = "Misc Data/Score", order = 1)] //<----------------------╗
public class SwatterNetwork : ScriptableObject                                                                 //|
{                                                                                                             /* |
    *The Fast Solution for Data Storage and Reference:  Make a GameObject -> Attach a Script -> Treat as usual.  |
    *The Correct Solution for Data Storage and Reference: This file.                                             |
    *When you want to store data that multiple game objects reference, you should make a                         |
    *Scriptable Object.  This avoids cloning large data structures                                               |
    * (which happens when you store gameobject references inside scripts), keeps your Hierarchy unclogged,       |
    *  and is more readable than stacked .GetComponent<>() calls.                                                |
    *  As a cool bonus, you get to define a UI element using this attribute notation ----------------------------╝
    *  under the Assets -> Create toolbar.
    */
    public int score;
}
